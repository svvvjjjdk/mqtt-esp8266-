//
// Created by 18881 on 25-8-31.
//

#include "it.h"
#include "uart_data_handle.h"
#include "usart.h"
#include "tim.h"
#include "mqtt.h"
extern "C" void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size) {
    if(huart->Instance == USART_ESP.Instance )
    {
        // Handle UART abort receive complete
        /*接收字节*/
        uint16_t received = RX_MAX_SIZE - __HAL_DMA_GET_COUNTER(huart->hdmarx);
        ucb_handle.Rxcounter+=received;
        /*将接收分段*/
        ucb_handle.RxINPtr->end = &U1_rxbuffer[ucb_handle.Rxcounter-1];
        ucb_handle.RxINPtr++;
        if(ucb_handle.RxINPtr == ucb_handle.RXEndPtr)
        {
            ucb_handle.RxINPtr = &ucb_handle.Rx_Location[0];
        }
        if((RX_BUFFER_SIZE-ucb_handle.Rxcounter) < RX_MAX_SIZE)
        {
            /*剩余内存不够，回卷*/
            ucb_handle.Rxcounter = 0;
            ucb_handle.RxINPtr->start = ucb_handle.RxINPtr->end= &U1_rxbuffer[0];
        }
        else
        {
            /*剩余内存够，继续*/
            ucb_handle.RxINPtr->start = ucb_handle.RxINPtr->end= &U1_rxbuffer[ucb_handle.Rxcounter];
        }
        HAL_UARTEx_ReceiveToIdle_DMA(&USART_ESP, const_cast<uint8_t*>(ucb_handle.RxINPtr->start), RX_MAX_SIZE);
    }
}
extern Mqtt_client Mqtt_client_ST;
extern "C" void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if(htim->Instance == htim6.Instance) {
        Mqtt_client_ST.mqtt_require_isr_handle();
    }
}