//
// Created by 18881 on 25-8-26.
//

#ifndef ESP8266_H
#define ESP8266_H
#include "main.h"
#include <string>
#define GPIO_ESP GPIOI
#define PIN_RESET GPIO_PIN_10
#define USART_PRINTF()

#define AT "AT\r\n" //AT指令
#define ATE "ATE0\r\n"
#define SUFFIX "\r\n"
/*网络链接*/
#define ESP_REST "AT+RST\r\n" //复位
#define ESP_RESTOE "AT+RESTORE\r\n" //恢复出厂设置
#define ESP_WIFE_STATION "AT+CWMODE=1\r\n" //设置为STATION模式
#define ESP_EXIT "+++"//退出透传
/*配网*/
#define SEVER_IP "\"192.168.218.125\""
#define ESP_PING "AT+PING="  //尝试网络连接
// #define ESP_AUTOSLINK "AT+SAVETRANSLINK=1,\"%s\",1883,\"TCP\"" //保存透传链接
#define ESP_AUTOSLINK "AT+SAVETRANSLINK=1" //保存透传链接
#define TRAN_FUN "\"TCP\""  //传输协议
#define PORT "1883"
#define ESP_WITF_CONFIG "AT+CWSTARTSMART=2\r\n" //微信配网
#define ESP_IP "AT+CIPSTA?\r\n"
#define OK "OK"
#define CLOSE "CLOSED"

class Esp {
public:
    explicit Esp(std::string name);
    /*复位*/
    static void esp_init();
    /*自动连接*/
    uint8_t esp_set_autolink();
private:    enum esp_status {
    NONE = 0,
    USE_ATE  ,
    ENTER_PING,
    ENTER_SET,
    SET_FINISHED
};
    esp_status esp_state = NONE;
    std::string esp_name;
    static uint8_t esp_cmd_write(const char* cmd,const char* rec);
};


#define ESP_UART huart4
#endif //ESP8266_H
