//
// Created by 18881 on 25-8-26.
//

#include "esp8266.h"
#include <cstring>
#include <uart_data_handle.h>
#include <string>
#include "usart.h"
using std::string;

/**
* \brief        Esp 构造函数
 * \param[out]  none
 * \param[in]   name esp名称
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/
Esp::Esp(std::string name) {
    esp_name = std::move(name);
    esp_init();
}

/**
* \brief        esp_init 初始化函数
 * \param[out]  none
 * \param[in]   none
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/
void Esp::esp_init()
{
    HAL_UART_Abort_IT(&ESP_UART);
    HAL_GPIO_WritePin(GPIO_ESP,PIN_RESET,GPIO_PIN_RESET);
    HAL_Delay(30);
    HAL_GPIO_WritePin(GPIO_ESP,PIN_RESET,GPIO_PIN_SET);
    HAL_Delay(1000);
    HAL_UARTEx_ReceiveToIdle_DMA(&USART_ESP,const_cast<uint8_t*>(ucb_handle.RxINPtr->start),RX_MAX_SIZE);
}

/**
* \brief        esp_cmd_write esp写命令
 * \param[out]  none
 * \param[in]   cmd 命令
 * \param[in]   rec 回复字符串
 * \return      none
 *      \arg
 *      \arg
*/
uint8_t Esp::esp_cmd_write(const char* cmd,const char* rec) {
    char str[512]{};
    if (ucb_handle.RxOUTPtr->start != ucb_handle.RxOUTPtr->end) {
        strncpy(str,reinterpret_cast<char*>(const_cast<uint8_t*>(ucb_handle.RxOUTPtr->start)),ucb_handle.RxOUTPtr->end-ucb_handle.RxOUTPtr->start+1);
        ucb_handle.RxOUTPtr++;
        if(ucb_handle.RxOUTPtr == ucb_handle.RXEndPtr)
        {
            ucb_handle.RxOUTPtr = &ucb_handle.Rx_Location[0];
        }
        usart2_printf(cmd,"\r\n");
        usart2_printf(str,"\r\n");
        if (strstr(cmd,"PING")!= nullptr) {
            if (strstr(str,"tim")!= nullptr || strstr(str,"busy")!= nullptr) {
                return 0;
            }
            return 1;
        }
        if (std::strstr(str,rec) != nullptr) {
            return 1;
        }
        if (std::strstr(str,ESP_EXIT) != nullptr)
        {
            return 1;
        }
    }
    else {
        uart1_send(reinterpret_cast<const uint8_t*>(cmd),strlen(cmd));
        HAL_Delay(200);
    }
    return 0;
}

/**
* \brief        esp_set_autolink 服务器自动连接状态机
 * \param[out]  none
 * \param[in]   none
 * \param[in]   none
 * \return      uint8_t
 *      \arg    1 连接完成
 *      \arg    0 连接中或者未连接
*/
uint8_t Esp::esp_set_autolink() {
    uint8_t ret = 0;
    std::string cmd_str{};
    if (esp_state == NONE) {
       ret = esp_cmd_write(ESP_EXIT,CLOSE);
        if (ret == 1) {
            esp_state = USE_ATE;
        }
    }
    else if (esp_state == USE_ATE) {
        ret = esp_cmd_write(ATE,OK);
        if (ret == 1) {
            esp_state = ENTER_PING;
        }
    }
    else if (esp_state == ENTER_PING) {
        // std::snprintf(str,100,ESP_PING,SEVER_IP);
        cmd_str = ESP_PING SEVER_IP SUFFIX;
        ret = esp_cmd_write(cmd_str.c_str(),"+");
        if (ret == 1) {
            esp_state = ENTER_SET;
        }
    }
    else if (esp_state == ENTER_SET) {
        // std::snprintf(str,100,ESP_AUTOSLINK,SEVER_IP);
        cmd_str = ESP_AUTOSLINK SEVER_IP SUFFIX;
        ret = esp_cmd_write(cmd_str.c_str(),OK);
        if (ret == 1) {
            esp_state = SET_FINISHED;
        }
    }
    else if (esp_state == SET_FINISHED) {
        esp_init();
        return 1;
    }
    return 0;
}



