//
// Created by 18881 on 25-8-31.
//

#include "device_app.h"
#include "mqtt.h"
#include  "cJSON.h"
extern Mqtt_client Mqtt_client_ST;

/**
* \brief        mqtt_get_chip_id 获取器件id，此处为stm32F4获取方法
 * \param[out]  none
 * \param[in]   none
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/

std::string get_st_chip_id() {
	uint32_t CpuID[3] = {0};
	CpuID[0] = *reinterpret_cast<uint32_t *>(0x1fff7a10);
	CpuID[1] = *reinterpret_cast<uint32_t *>(0x1fff7a14);
	CpuID[2] = *reinterpret_cast<uint32_t *>(0x1fff7a18);
	std::string id = std::to_string(CpuID[0]) + std::to_string(CpuID[1]) + std::to_string(CpuID[2]);
	return id;
}
/**
* \brief        msg_handler  接收消息处理
 * \param[out]
 * \param[in]   payload 载荷
 * \param[in]   payload_len 载荷长度
 * \return      none
 *      \arg
 *      \arg
*/
void msg_handler(uint8_t*payload ,int payload_len) {

}

/**
* \brief        device_msg_submit  设备信息上交
 * \param[out]
 * \param[in]
 * \param[in]
 * \return      none
 *      \arg
 *      \arg
*/
void device_msg_submit(const uint8_t dup) {
	cJSON*root = cJSON_CreateObject();

 /*id*/
	 cJSON_AddStringToObject(root,Uid,Mqtt_client_ST.mqtt_get_chip_id().c_str());

	 /*msg type*/
	 cJSON_AddNumberToObject(root,Code,Device_msg_submit);

	 /************device**********/
	 /*led*/
	 cJSON *ledroot = cJSON_CreateArray();

	 cJSON *led0 = cJSON_CreateObject();
	 cJSON_AddNumberToObject(led0,"status",1);
	 cJSON_AddNumberToObject(led0,"num",0);
	 cJSON_AddItemToArray(ledroot,led0);

	 cJSON *led1 = cJSON_CreateObject();
	 cJSON_AddNumberToObject(led1,"status",1);
	 cJSON_AddNumberToObject(led1,"num",1);
	 cJSON_AddItemToArray(ledroot,led1);

	 cJSON_AddItemToObject(root,"LED",ledroot);

    /**/

    /***********信息准备**************/
    char*msg = cJSON_PrintUnformatted(root);

    Mqtt_client_ST.mqtt_msg_publish(msg,1,dup);

    /*json delete*/
	cJSON_free(msg);
    cJSON_Delete(root);
}

/**
* \brief        mqtt_online_send  上线信息
 * \param[out]
 * \param[in]
 * \param[in]
 * \return      none
 *      \arg
 *      \arg
*/
void mqtt_online_send(const uint8_t dup)
{
	char* msg;
	cJSON*root = cJSON_CreateObject();
	cJSON_AddStringToObject(root,Uid,Mqtt_client_ST.mqtt_get_chip_id().c_str());				//id
	cJSON_AddNumberToObject(root,Code,Mqtt_client::device_online);  //上线
	cJSON*msgobj = cJSON_CreateArray();
	cJSON_AddItemToArray(msgobj,cJSON_CreateNumber(LED));	//添加控制节点
	cJSON_AddItemToObject(root,Msg,msgobj);
	msg = cJSON_PrintUnformatted(root);
	cJSON_Delete(root);
	Mqtt_client_ST.mqtt_msg_publish(msg,1,dup);
	cJSON_free(msg);
}

