//
// Created by 18881 on 25-8-31.
//

#ifndef DEVICE_APP_H
#define DEVICE_APP_H
#include <string>

#include "main.h"
/*
 * 格式：
 * {
    "UID":		,
    "code":		,
    "LED":[{},{}]
    }
 */

enum Device_msg_status {
    Device_msg_submit = 100,
};

enum Device_type {
     LED = 0,
};

void mqtt_online_send(const uint8_t dup);
std::string get_st_chip_id();
void device_msg_submit(const uint8_t dup);
void msg_handler(uint8_t*payload ,int payload_len);




#endif //DEVICE_APP_H

