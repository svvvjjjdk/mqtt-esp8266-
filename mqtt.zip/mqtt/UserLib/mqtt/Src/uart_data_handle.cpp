//
// Created by 18881 on 25-8-22.
//

#include "uart_data_handle.h"
#include "usart.h"
#include <string>

uint8_t U1_rxbuffer[RX_BUFFER_SIZE]{};
UCB ucb_handle;
void UCB_Init(UCB*handle) {
    for (int i = 0; i < 10; i++) {
        handle->Rx_Location[i].start = handle->Rx_Location[i].end = NULL;
    }
    handle->RxINPtr = &handle->Rx_Location[0];
    handle->RxOUTPtr = &handle->Rx_Location[0];
    handle->RXEndPtr = &handle->Rx_Location[9];
    handle->Rxcounter = 0;
    handle->RxINPtr->start = handle->RxINPtr->end= U1_rxbuffer;
    HAL_UARTEx_ReceiveToIdle_DMA(&USART_ESP,const_cast<uint8_t*>(handle->RxINPtr->start),RX_MAX_SIZE);
}

int mqtt_getchar(uint8_t *buf, int size) {
    int res = 0;
    static uint8_t flag = 0;    //确认读取完毕标志

    if ((ucb_handle.RxOUTPtr->start == ucb_handle.RxOUTPtr->end)&&(flag == 0)) {
        return -1;
    }
    /*未读完标志置位*/
    flag = 1;
    while(res < size)
    {
        if (ucb_handle.RxOUTPtr->start == ucb_handle.RxOUTPtr->end) {
            *buf = *(ucb_handle.RxOUTPtr->start);
            ucb_handle.RxOUTPtr++;
            if(ucb_handle.RxOUTPtr == ucb_handle.RXEndPtr)
            {
                ucb_handle.RxOUTPtr = &ucb_handle.Rx_Location[0];
            }
            /*读取完毕*/
            flag = 0;
        }
        else {
            *buf = *(ucb_handle.RxOUTPtr->start++);
        }
        buf++;
        res++;
    }
    return res;
}


void uart1_send(const uint8_t* msg,uint32_t len) {
    HAL_UART_Transmit(&USART_ESP,msg,len,1000);
}
void uart2_send(const char* msg,uint32_t len) {
    __disable_irq();
    HAL_UART_Transmit(&USART_TEST,reinterpret_cast<uint8_t*>(const_cast<char*>(msg)),len,1000);
    __enable_irq();
}



