//
// Created by 18881 on 25-8-21.
//


#include "mqtt.h"
#include <cstring>
#include <list>
#include "cJSON.h"
#include "uart_data_handle.h"
#include "MQTTPacket.h"
/**
* \brief       Mqtt_client 构造函数
 * \param[in]   id 器件id
 * \param [in] user_account 用户账号
 * \param [in] password     用户密码
 * \return  none
*/
Mqtt_client::Mqtt_client(std::string user_account,std::string password,std::string id):
chip_id(std::move(id)),
server_account(std::move(user_account)),
server_password(std::move(password))
{}

/**
* \brief        mqtt_connect  连接服务器
 * \param[out]  will_topic 遗嘱主题
 * \param[in]   Keep_Alive_Interval 心跳
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_connect(const std::string& will_topic,uint8_t Keep_Alive_Interval){
   if (this->status == device_offline) {
      cJSON* root;				//JSON，模板

      uint8_t buffer[300]{};
      this->keep_alive_interval = Keep_Alive_Interval;
      MQTTPacket_connectData connectData = MQTTPacket_connectData_initializer;
      /*MQTT序列化*/
      MQTTString username = MQTTString_initializer;
      MQTTString password = MQTTString_initializer;
      username.cstring =  const_cast<char *>(this->server_account.c_str()); // 替换为实际用户名
      password.cstring =  const_cast<char *>(this->server_password.c_str()); // 替换为实际密码

      /*参数*/
      connectData.username = username;
      connectData.password = password;
      connectData.clientID.cstring = this->chip_id.data(); // 替换为实际客户端ID
      connectData.keepAliveInterval = this->keep_alive_interval; // 心跳维持60s，这个时间段内发心跳包
      connectData.cleansession = 1; // 清除会话

      MQTTString willtopicname = MQTTString_initializer;
      willtopicname.cstring = const_cast<char *>(will_topic.c_str()); // 替换为实际主题
      connectData.will.topicName = willtopicname; // 设置遗嘱消息主题

      MQTTString willtopicmsg = MQTTString_initializer;
      root = cJSON_CreateObject();; //添加一个JSON对象，用于放于遗嘱消息
      cJSON_AddStringToObject(root,Uid,this->chip_id.data());   //添加client ID
      cJSON_AddNumberToObject(root,Code,device_offline);			//添加消息类型，0为下线（遗嘱）消息类型
      std::string will_msg = chip_id +" device off";
      cJSON_AddStringToObject(root,Msg,will_msg.c_str());	//添加遗嘱消息

      char* temp = cJSON_PrintUnformatted(root);
      willtopicmsg.cstring = temp;
      connectData.will.message = willtopicmsg; // 设置遗嘱消息内容

      connectData.will.qos = 1; // 设置遗嘱消息的QoS等级
      connectData.willFlag = 1; // 启用遗嘱消息

      int len = MQTTSerialize_connect(buffer,  sizeof(buffer), &connectData);
      if (len <= 0) {
       // 错误处理
       usart2_printf("connect send error\r\n");
       return;
      }
      // 发送连接数据
      uart1_send(buffer, len);
      cJSON_free(temp);
      cJSON_Delete(root);						//删除cJSON对象
   }
}

/**
* \brief        mqtt_subscribe 订阅主题
 * \param[out]  Topic 订阅主题
 * \param[in]   qos 消息等级
 * \param[in]   dup 是否重发 0 不是，1是
 * \return      uint8_t
 *      \arg    1  序列化成功
 *      \arg    0  序列化失败
*/
uint8_t Mqtt_client::mqtt_subscribe(std::string Topic[], uint8_t size, int qos[], uint8_t dup) {
 if (status != device_offline) {
    uint8_t buffer[300];
    auto topic = new MQTTString[size];
    for (uint8_t i = 0; i < size; i++) {
     topic[i] = MQTTString_initializer;
     topic[i].cstring = Topic[i].data();
    }
    int len = MQTTSerialize_subscribe(buffer,sizeof(buffer),dup,1,size,topic,qos);
    if (len <= 0) {
     usart2_printf("sub send error","\r\n");
     return 0 ;
    }
    uart1_send(buffer,len);
    delete [] topic;
 }
 return 1;
}

/**
* \brief        mqtt_subscribe 订阅主题
 * \param[out]  Topic 订阅主题
 * \param[in]   qos 消息等级
 * \param[in]   dup 是否重发 0 不是，1是
 * \return      none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_msg_publish(std::string msg, uint8_t qos,uint8_t dup) {
 if (status != device_offline) {
     MQTTString topic = MQTTString_initializer;
     topic.cstring = const_cast<char*>(Topic);
     int len = MQTTPacket_len(MQTTSerialize_publishLength(qos, topic, static_cast<int>(msg.length())+1));
     if(len <= 0) {
      usart2_printf("MQTT serialize publish length error!\n");
      return;
     }
     auto *buf = new uint8_t[len];
     /*序列化*/
     len = MQTTSerialize_publish(buf, len, dup, qos, 1, mqttpackid, topic,
                                 reinterpret_cast<uint8_t*>(msg.data()), static_cast<int>(msg.length())+1);

     if(len <= 0) {
      usart2_printf("MQTT serialize publish failed!\n");
      delete[] buf;
      return;
     }
     /*发送消息*/
     uart1_send(buf, len);
     if(qos != 0) {
      insert_mqtt_msg(buf, len, mqttpackid); // 链表管理内存
     }
     delete[] buf;
     mqttpackid++;
     if(mqttpackid >= 65535) {
      mqttpackid = 2;
     }
 }

}
#if RECEIVE_FLOW == 1
/**
* \brief        mqtt_getchar 流式读取
 * \param[out]  buf 存放buf
 * \param[in]   size buf大小
 * \return      none
 *      \arg
 *      \arg
*/
int Mqtt_client:: mqtt_getchar(uint8_t *buf, int size) {
    int res = 0;
    while(size!=0)
    {
     *buf = (this->rx_buffer)[mqtt_count++];
     buf++;
     size--;
     res++;
    }
    return res;
}
#endif
/**
* \brief        mqtt_puback_get 获取包id
 * \param[out]  buf 消息
 * \param[in]   buflen 消息长度
 * \return      uint16_t
 *      \arg    packid
 *      \arg
*/

uint16_t Mqtt_client::mqtt_puback_get_id(uint8_t buf[],int buflen) {
         uint16_t packid;
         uint8_t dup;
         uint8_t packetype[20];
         MQTTDeserialize_ack(packetype,&dup,&packid,buf,buflen);
         return packid;
}
/**
* \brief        mqtt_handle_publish_msg 处理推送的消息
 * \param[out]  none
 * \param[in]   buffer 消息载体
 * \param[in]   bu_len 消息长度
 * \return      none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_handle_publish_msg(const uint8_t *buffer,int bu_len) const {
 if (status == device_online) {
  uint8_t *payLoadIn; //有效载荷，指向消息内容（Payload）数据的起始地址。
  int payLoadlenIn = 0;
  uint8_t dup;				//是否为重复发送（1=是，0=否）
  int qos;
  int size;
  uint8_t retained;		//是否为保留消息（1=是，0=否）
  uint16_t msgId;			//信息id
  MQTTString receiveTopic = MQTTString_initializer;
  uint8_t bufRec[20] = {0};
  if(MQTTDeserialize_publish(&dup,&qos,&retained,&msgId,&receiveTopic,&payLoadIn,&payLoadlenIn,const_cast<uint8_t*>(buffer),bu_len) == 1)
  {
   switch(qos)
   {
    case 1:
     size = MQTTSerialize_puback(bufRec,sizeof(bufRec),msgId);

     uart1_send(bufRec, size);
     break;
    case 2:
     size = MQTTSerialize_pubrec(bufRec,sizeof(bufRec),msgId);

     uart1_send(bufRec, size);
     break;
   }
   usart2_printf("msgrec:",payLoadIn,"\r\n");
   if (cb_function != nullptr)
    cb_function(payLoadIn,payLoadlenIn);
   else
    usart2_printf("cb_foution is null!\r\n");
  }
 }

}

/**
* \brief        mqtt_pubrec_handle 第一次握手处理
 * \param[out]  buf 包数据
 * \param[in]   buf_len 数据长度
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_pubrec_handle(uint8_t buf[],int buf_len) {
     uint16_t packid;
     uint8_t dup;
     uint8_t packetype[20];
     if(MQTTDeserialize_ack(packetype,&dup,&packid,buf,buf_len) !=1)
      usart2_printf("purec error\r\n");
     buf_len = MQTTSerialize_pubrec(buf,buf_len,packid);
     uart1_send(buf,buf_len);
}


/**
* \brief        mqtt_pubrel_handle 第二次握手处理
 * \param[out]  buf 包数据
 * \param[in]   buf_len 数据长度
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_pubrel_handle(uint8_t buf[],int buf_len) {
     uint16_t packid;
     uint8_t dup;
     uint8_t packetype[20];
     if(MQTTDeserialize_ack(packetype,&dup,&packid,buf,buf_len) !=1)
      usart2_printf("purel error\r\n");
     buf_len = MQTTSerialize_pubrel(buf,buf_len,dup,packid);
     uart1_send(buf,buf_len);
}

/**
* \brief        mqtt_pubcomp_handle 第三次握手处理
 * \param[out]  buf 包数据
 * \param[in]   buf_len 数据长度
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_pubcomp_handle(uint8_t buf[],int buf_len) {
     uint16_t packid;
     uint8_t dup;
     uint8_t packetype[20];
     if(MQTTDeserialize_ack(packetype,&dup,&packid,buf,buf_len) !=1)
      usart2_printf("pubcomp error\r\n");
      buf_len = MQTTSerialize_pubcomp(buf,buf_len,packid);
      uart1_send(buf,buf_len);
}
/**
* \brief        mqtt_msg_handler 消息调度
 * \param[out]  none
 * \param[in]   none
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/
// __weak int Mqtt_client::mqtt_msg_handler() {
//
//     int mqtt_type = MQTTPacket_read(this->buf, buf_len, mqtt_getchar);
//     const uint16_t pack_id = mqtt_puback_get_id(buf,buf_len);
// #if RECEIVE_FLOW == 1
//      this->mqtt_count = 0;
// #endif
//      switch (mqtt_type) {
//       /*连接回复*/
//       case CONNACK: {
//            this->status = device_connected;
//            usart2_printf("CONNECT received\r\n");
//       }
//        break;
//
//        /*接收到消息*/
//       case PUBLISH: {
//            mqtt_handle_publish_msg(buf,buf_len);
//       }
//
//        break;
//
//        /*qos = 1消息发送后的回复*/
//       case PUBACK: {
//            if (this->status == device_connected) {
//              if (pack_id == 1) {
//               this->status = device_online;
//               usart2_printf(this->chip_id," device oline","\r\n");
//              }
//            }
//            else {
//             usart2_printf("PUBACK\r\n");
//            }
//            remove_mqtt_msg(pack_id);
//       }
//        break;
//        /*qos =2 三次握手*/
//        /*第一次*/
//       case PUBREC:
//        mqtt_pubrec_handle(buf,buf_len);
//        break;
//
//        /*第二次*/
//       case PUBREL:
//        mqtt_pubrel_handle(buf,buf_len);
//        break;
//
//        /*第三次*/
//       case PUBCOMP:
//        mqtt_pubcomp_handle(buf,buf_len);
//        remove_mqtt_msg(pack_id);
//        break;
//
//        /*订阅回复*/
//       case SUBACK:{
//            if (this->status == device_connected) {
//             usart2_printf("SUBACK Init received\r\n");
//            }
//            else if (this->status == device_online) {
//             usart2_printf("SUBACK received\r\n");
//            }
//            break;
//      }
//        /*心跳回复*/
//       case PINGRESP:
//            usart2_printf("PINGRESP\r\n");
//            PINGRESP_reset_time_count = 0;
//         break;
//      }
//  return mqtt_type;
// }
void Mqtt_client::mqtt_msg_handler() {
 static uint32_t now_time = 0;
 static uint8_t sub_times;
 int mqtt_type = 0 ;
 if (status != device_offline) {
  mqtt_type = MQTTPacket_read(buf, buf_len, mqtt_getchar);
  #if RECEIVE_FLOW == 1
       mqtt_count = 0;s
  #endif
 }
 switch (status) {
  case device_offline:
   mqtt_connect("MinLastWillTopic",60);
   now_time = HAL_GetTick();
   status = device_connected_request;
   sub_times = 0;
   break;

  case device_connected_request:
   if (mqtt_type == CONNACK) {
    status = device_connected;
    usart2_printf("CONNECT received\r\n");
   }
   else if (HAL_GetTick() - now_time > 1000) {
    status = device_offline;
   }
   break;

  case device_connected: {
   std::string topic[2] = {"device/all","device/"+mqtt_get_chip_id()};
   int qos_i[2] = {1,1};
   mqtt_subscribe(topic,2,qos_i,0);
   now_time = HAL_GetTick();
   status = device_subscribed_request;
   break;
  }

  case device_subscribed_request:
   if (mqtt_type == SUBACK) {
    status = device_subscribed;
    usart2_printf("SUBACK Init received\r\n");
   }
   else if (HAL_GetTick() - now_time > 1000) {
    status = device_connected;
    sub_times++;
    if (sub_times > 3) {
     status = device_offline;
    }
   }
   break;

  case device_subscribed:
   if (cb_online_function != nullptr)
    cb_online_function(0);
   status = device_online;
   break;

  case device_online:
   if (mqtt_type == PUBACK) {
    status = device_run;
    mqtt_send_ping();
    remove_mqtt_msg(1);
    usart2_printf(mqtt_get_chip_id()," device oline","\r\n");
   }
   break;

   case device_run: {
    const uint16_t pack_id = mqtt_puback_get_id(buf, buf_len);
    switch (mqtt_type) {
     case PUBLISH: {
      mqtt_handle_publish_msg(buf,buf_len);
     }
      break;
     /*qos = 1 */

     case PUBACK: {
      usart2_printf("PUBACK\r\n");
      remove_mqtt_msg(pack_id);
     }
      break;

      /*qos =2 三次握手*/
      /*第一次*/
     case PUBREC:
      mqtt_pubrec_handle(buf,buf_len);
      break;

      /*第二次*/
     case PUBREL:
      mqtt_pubrel_handle(buf,buf_len);
      break;

      /*第三次*/
     case PUBCOMP:
      mqtt_pubcomp_handle(buf,buf_len);
      remove_mqtt_msg(pack_id);
      break;

      /*订阅回复*/
     case SUBACK:{
      usart2_printf("SUBACK received\r\n");
      break;
     }
      /*心跳回复*/
     case PINGRESP:
      usart2_printf("PINGRESP\r\n");
      PINGRESP_reset_time_count = 0;
      break;
    }
   }
   break;
  default:
   break;
 }
}
/**
* \brief        mqtt_msg_handle_cb_register 消息处理回调
 * \param[out]  none
 * \param[in]   cb   回调函数
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_msg_handle_cb_register(msg_handler_callback cb) {
     cb_function = cb;
}
/**
* \brief        mqtt_online_cb_register 上线消息注册
 * \param[out]  none
 * \param[in]   cb   回调函数
 * \param[in]   none
 * \return      none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_online_cb_register(msg_online_callback cb) {
     cb_online_function = cb;
}
/**
 * \brief insert_mqtt_msg 向消息链表中插入消息
 * \param[out] none
 * \param[in] msg
 * \param[in] bulen
 * \return uint8_t
 *      \arg 0 成功
 *      \arg 1 失败
*/
uint8_t Mqtt_client::insert_mqtt_msg(const uint8_t *msg, const int msglen, uint16_t mqttpackid) {
        mqtt_msg_t msg_item = {};
        msg_item.msg = std::unique_ptr<uint8_t[]>(new uint8_t[msglen]);
        std::memcpy(msg_item.msg.get(), msg, msglen);
        msg_item.msglen = msglen;
        msg_item.send_count = 0;
        msg_item.time_peroid = 0;
        //	msg_item.qos = qos;
        msg_item.packid = mqttpackid;
        mqtt_msg_send_queue.push(std::move(msg_item));
        return 1;
}
/**
 * \brief remove_mqtt_msg 从消息链表中删除消息
 * \param[out] none
 * \param[in] packid
 * \return uint8_t
 *      \arg 0 成功
 *      \arg 1 失败
*/
uint8_t Mqtt_client::remove_mqtt_msg(uint16_t packid) {
        mqtt_msg_t msg_item = {};
        msg_item.packid = packid;
        /*删去头结点*/
        if (!mqtt_msg_send_queue.empty())
        mqtt_msg_send_queue.pop();
        return 1;
}
/**
 * \brief mqtt_item_compare  检测mqtt的两个信号是否相同
 * \param[out] none
 * \param[in] item1
 * \param[in] item2
 * \return uint8_t
 *      \arg 1 相同
 *      \arg 0 不相同
*/
uint8_t Mqtt_client::mqtt_item_compare(mqtt_msg_t *item1, const mqtt_msg_t *item2) {
        /*自定义比较方式*/
        if(item1->packid == item2->packid)
        {
         return 1;
        }
        return 0;
}
/**
 * \brief mqtt_msg_timeperiod_handle  消息发送队列定时处理
 * \param[out] none
 * \param[in] none
 * \param[in] none
 * \return none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_send_ping() {
     uint8_t heartbeat[2] = {0xc0,0x00};
     uart1_send(heartbeat,2);
}
/**
 * \brief mqtt_msg_timeperiod_handle  消息发送队列定时处理
 * \param[out] none
 * \param[in] none
 * \param[in] none
 * \return none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_msg_timeperiod_handle() {

     if (mqtt_msg_send_queue.empty()) {
      return;
     }
     mqtt_msg_send_queue.front().time_peroid++;
     if(mqtt_msg_send_queue.front().time_peroid>1)
     {
      mqtt_msg_send_queue.front().time_peroid = 0;
      mqtt_msg_send_queue.front().send_count++;
      uart1_send( mqtt_msg_send_queue.front().msg.get(), mqtt_msg_send_queue.front().msglen);
     }
     if(mqtt_msg_send_queue.front().send_count>3)
     {
      if(mqtt_msg_send_queue.front().packid == 1)
      {
       status = device_offline;
      }
      usart2_printf("packid:",mqtt_msg_send_queue.front().packid,"send error\r\n");
      remove_mqtt_msg(mqtt_msg_send_queue.front().packid);
 }
}

/**
 * \brief mqtt_require_isr_handle  心跳请求，队列信息处理
 * \param[out] none
 * \param[in] none
 * \param[in] none
 * \return none
 *      \arg
 *      \arg
*/
void Mqtt_client::mqtt_require_isr_handle() {
 if (status != device_offline) {
  mqtt_msg_timeperiod_handle();
  static uint8_t PINGRESP_time_counter = 0; //心跳请求计数
  if (PINGRESP_time_counter == 40) {
   /*每40s请求心跳*/
   mqtt_send_ping();
   PINGRESP_time_counter = 0;
  }
  if (PINGRESP_reset_time_count >= 60 ) {
   status = device_offline;
  }
  PINGRESP_time_counter++;
  PINGRESP_reset_time_count++;
 }
}

