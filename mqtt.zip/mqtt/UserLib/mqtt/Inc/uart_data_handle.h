//
// Created by 18881 on 25-8-22.
//

#ifndef UART_DATA_HANDLE_H
#define UART_DATA_HANDLE_H
#include "main.h"
#include <sstream>

/*数组长度*/
#define RX_BUFFER_SIZE 2048
#define RX_MAX_SIZE 512         //对方发送一次最大数据量+1，为了防止空闲和接收完成中断同时产生
#define USART_ESP huart4
#define USART_TEST huart1

/*缓存区控制双指针*/
typedef struct
{
   volatile uint8_t *start;  //接收数据起始地址
   volatile uint8_t *end;    //接收数据结束地址
} LDB;

typedef struct
{
   volatile uint32_t Rxcounter;         //接收计数
   volatile LDB Rx_Location[10];
   volatile LDB *RxINPtr;              //RXLocation头指针
   volatile LDB *RxOUTPtr;             //RXLocation输出指针
   volatile LDB *RXEndPtr;             //RXLocation尾指针
}UCB;

extern UCB ucb_handle;
extern uint8_t U1_rxbuffer[];
void UCB_Init(UCB*handle);
int mqtt_getchar(uint8_t *buf, int size);
void uart1_send(const uint8_t* msg,uint32_t len);
void uart2_send(const char* msg,uint32_t len);


template <typename... Args>void usart2_printf(Args&&... args)
{
    std::ostringstream oss;
    (oss << ... << args);  // fold expression，把所有参数流进来
    std::string msg = oss.str();
    uart2_send(msg.c_str(),msg.size());
}



#endif //UART_DATA_HANDLE_H
