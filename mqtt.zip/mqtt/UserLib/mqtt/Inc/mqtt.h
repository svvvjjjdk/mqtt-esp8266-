//
// Created by 18881 on 25-8-21.
//

#ifndef MQTT_H
#define MQTT_H
#include "main.h"
#include <string>
#include <memory>
#include <queue>
/*1:如果使用自带流式读取,0:自己写 int mqtt_getchar(const uint8_t *buf, int size);*/
#define RECEIVE_FLOW 0


/*使用的信息标识符号*/
inline const char* Uid = "uid";			//客户id
inline const char* Code = "code";		//事件编号
inline const char* Msg   = "msg";		//信息
inline const char* Topic = "stm32/to/server";  //本机主题

/*mqtt类*/
class  Mqtt_client {
private:
    /******************变量***********************/
    /*设备状态*/
    enum device_status {
        device_offline = 0,
        device_online,
        device_connected_request,
        device_connected,
        device_subscribed_request,
        device_subscribed,
        device_run,
    };
    typedef struct
    {
        std::unique_ptr<uint8_t []> msg;	//信息实体指针
        int msglen;				 //消息长度
        uint16_t packid;				 //发送包id
        uint8_t send_count;    //重发次数
        uint16_t time_peroid;   //重发事件间隔
        uint8_t find_count;     //记录查询次数方便删除
    }mqtt_msg_t;
    /*信息处理回调函数处理模板*/
    using msg_handler_callback = void(*)(uint8_t*payload ,int payload_len);
    using msg_online_callback = void(*)(uint8_t dup);
    /*本stm32F4 ID*/
    std::string chip_id = "1234324234";
    /*server account*/
    std::string server_account;
    /*server password*/
    std::string server_password;
    /*心跳时间 heart_beat_time*/
    uint8_t keep_alive_interval = 0;
    /*发送消息包*/
    uint16_t mqttpackid = 1;
    /*消息处理回调函数存放处*/
    msg_handler_callback cb_function= {nullptr};
    msg_online_callback  cb_online_function = {nullptr};
    /*解析缓冲区*/
    static constexpr uint16_t buf_len  = 1024;
    uint8_t buf[buf_len] {};
    /*设备状态*/
    device_status status = device_offline;
    /*发送链表*/
    std::queue<mqtt_msg_t> mqtt_msg_send_queue;
    //心跳接收复位
    volatile uint8_t PINGRESP_reset_time_count = 0;
    /*心跳请求*/
    static void mqtt_send_ping();
#if RECEIVE_FLOW == 1
    /*流式接收偏移*/
    volatile int mqtt_count= 0;/*流式接收*/
    char* rx_buffer = nullptr;
    /******************内部处理***********************/
    int mqtt_getchar(uint8_t *buf, int size);
#endif
    /*对推送的消息处理*/
    void mqtt_handle_publish_msg(const uint8_t *buf,int bu_len) const;
    /*第一次握手处理*/
    static void mqtt_pubrec_handle(uint8_t buf[], int buf_len);
    /*第二次握手处理*/
    static void mqtt_pubrel_handle(uint8_t buf[],int buf_len);
    /*第三次握手处理*/
    static void mqtt_pubcomp_handle(uint8_t buf[],int buf_len);
    /******************内部处理—发送消息***********************/
    /*添加发送信号*/
    uint8_t insert_mqtt_msg(const uint8_t *msg,const int msglen,uint16_t mqttpackid);
    /*移除发送信号*/
    uint8_t remove_mqtt_msg(uint16_t packid);
    /*消息识别*/
    static uint8_t mqtt_item_compare(mqtt_msg_t *item1 ,const mqtt_msg_t *item2);
    /*消息发送周期性处理*/
    void mqtt_msg_timeperiod_handle();
public:
    /******************接口***********************/
    /*构造函数*/
    explicit Mqtt_client(std::string user_account,std::string password,std::string id);
    /*连接服务器*/
    void mqtt_connect(const std::string& will_topic, uint8_t Keep_Alive_Interval);
    /*订阅Topic*/
    uint8_t mqtt_subscribe(std::string Topic[], uint8_t size, int qos[], uint8_t dup);
    /*消息推送*/
    void mqtt_msg_publish(std::string msg, uint8_t qos, uint8_t dup);
    /*消息解析中枢*/
    void mqtt_msg_handler();
    /*获取包返回id*/
    static uint16_t mqtt_puback_get_id(uint8_t buf[],int buflen);
#if RECEIVE_FLOW == 1
    /*信息接收缓冲区导入*/
    void mqtt_connect_rx_buffer(uint8_t* buffer);
#endif
    /*消息处理回调注册*/
    void mqtt_msg_handle_cb_register(msg_handler_callback cb);
    /*上线消息注册*/
    void mqtt_online_cb_register(msg_online_callback cb);
    /*获取设别状态*/
    device_status mqtt_get_status()  {
        return status;
    };
    /*获取已经产生的器件id*/
    std::string& mqtt_get_chip_id() {
        return  chip_id;
    }
    /*放于中断或者定时器中用于获取心跳和数据发送*/
    void mqtt_require_isr_handle();
};

#endif //MQTT_H
