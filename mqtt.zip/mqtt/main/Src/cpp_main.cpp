//
// Created by 18881 on 25-8-21.
//

#include "usart.h"
#include "gpio.h"
#include "tim.h"
#include "cpp_main.h"
#include "uart_data_handle.h"
#include "device_app.h"
#include "dma.h"
#include "mqtt.h"
#include "esp8266.h"
Mqtt_client Mqtt_client_ST("andy","123456",get_st_chip_id());

 int main()
{

    /* USER CODE BEGIN 1 */

    /* USER CODE END 1 */

    /* MCU Configuration--------------------------------------------------------*/

    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
    HAL_Init();

    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* Configure the system clock */
    SystemClock_Config();

    /* USER CODE BEGIN SysInit */

    /* USER CODE END SysInit */

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_UART4_Init();
    MX_USART1_UART_Init();
    MX_TIM6_Init();
    /* USER CODE BEGIN 2 */
    // mem_init();
    UCB_Init(&ucb_handle);
    Esp esp8266("esp8266");
    int ret = 0;
    Mqtt_client_ST.mqtt_msg_handle_cb_register(msg_handler);
    Mqtt_client_ST.mqtt_online_cb_register(mqtt_online_send);
    /* USER CODE END 2 */

    /* Infinite loop */

    /* USER CODE BEGIN WHILE */
    while (1) {
        /* USER CODE END WHILE */

        /* USER CODE BEGIN 3 */
        if (!ret)
        ret = esp8266.esp_set_autolink();
        else {
            Mqtt_client_ST.mqtt_msg_handler();
        }
    }
    /* USER CODE END 3 */
}